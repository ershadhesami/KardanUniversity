﻿namespace MidTermExam
{
    partial class CustomizedMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomizedMenu));
            this.pnlMenu = new System.Windows.Forms.Panel();
            this.btnPurchase = new System.Windows.Forms.Button();
            this.btnSale = new System.Windows.Forms.Button();
            this.pnlSaleDropdown = new System.Windows.Forms.Panel();
            this.btnSaleWholesale = new System.Windows.Forms.Button();
            this.btnSaleRetail = new System.Windows.Forms.Button();
            this.pnlPurchaseDropdown = new System.Windows.Forms.Panel();
            this.btnPurchaseWholesale = new System.Windows.Forms.Button();
            this.btnPurchaseRetail = new System.Windows.Forms.Button();
            this.picTick = new System.Windows.Forms.PictureBox();
            this.pnlMenu.SuspendLayout();
            this.pnlSaleDropdown.SuspendLayout();
            this.pnlPurchaseDropdown.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picTick)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMenu
            // 
            this.pnlMenu.BackColor = System.Drawing.Color.LightSeaGreen;
            this.pnlMenu.Controls.Add(this.picTick);
            this.pnlMenu.Controls.Add(this.btnPurchase);
            this.pnlMenu.Controls.Add(this.btnSale);
            this.pnlMenu.Location = new System.Drawing.Point(0, 0);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.Size = new System.Drawing.Size(602, 54);
            this.pnlMenu.TabIndex = 0;
            // 
            // btnPurchase
            // 
            this.btnPurchase.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnPurchase.FlatAppearance.BorderSize = 0;
            this.btnPurchase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPurchase.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPurchase.ForeColor = System.Drawing.SystemColors.Control;
            this.btnPurchase.Location = new System.Drawing.Point(122, 0);
            this.btnPurchase.Name = "btnPurchase";
            this.btnPurchase.Size = new System.Drawing.Size(116, 54);
            this.btnPurchase.TabIndex = 2;
            this.btnPurchase.Text = "Purchase";
            this.btnPurchase.UseVisualStyleBackColor = false;
            this.btnPurchase.Click += new System.EventHandler(this.BtnPurchase_Click);
            this.btnPurchase.MouseEnter += new System.EventHandler(this.BtnPurchase_MouseEnter);
            // 
            // btnSale
            // 
            this.btnSale.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnSale.FlatAppearance.BorderSize = 0;
            this.btnSale.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSale.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSale.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSale.Location = new System.Drawing.Point(0, 0);
            this.btnSale.Name = "btnSale";
            this.btnSale.Size = new System.Drawing.Size(116, 54);
            this.btnSale.TabIndex = 1;
            this.btnSale.Text = "Sale";
            this.btnSale.UseVisualStyleBackColor = false;
            this.btnSale.Click += new System.EventHandler(this.BtnSale_Click);
            this.btnSale.MouseEnter += new System.EventHandler(this.BtnSale_MouseEnter);
            // 
            // pnlSaleDropdown
            // 
            this.pnlSaleDropdown.BackColor = System.Drawing.Color.LightSeaGreen;
            this.pnlSaleDropdown.Controls.Add(this.btnSaleWholesale);
            this.pnlSaleDropdown.Controls.Add(this.btnSaleRetail);
            this.pnlSaleDropdown.Location = new System.Drawing.Point(0, 54);
            this.pnlSaleDropdown.Name = "pnlSaleDropdown";
            this.pnlSaleDropdown.Size = new System.Drawing.Size(116, 122);
            this.pnlSaleDropdown.TabIndex = 3;
            // 
            // btnSaleWholesale
            // 
            this.btnSaleWholesale.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnSaleWholesale.FlatAppearance.BorderSize = 0;
            this.btnSaleWholesale.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaleWholesale.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaleWholesale.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSaleWholesale.Location = new System.Drawing.Point(0, 60);
            this.btnSaleWholesale.Name = "btnSaleWholesale";
            this.btnSaleWholesale.Size = new System.Drawing.Size(116, 54);
            this.btnSaleWholesale.TabIndex = 4;
            this.btnSaleWholesale.Text = "Wholesale";
            this.btnSaleWholesale.UseVisualStyleBackColor = false;
            // 
            // btnSaleRetail
            // 
            this.btnSaleRetail.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnSaleRetail.FlatAppearance.BorderSize = 0;
            this.btnSaleRetail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaleRetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaleRetail.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSaleRetail.Location = new System.Drawing.Point(0, 0);
            this.btnSaleRetail.Name = "btnSaleRetail";
            this.btnSaleRetail.Size = new System.Drawing.Size(116, 54);
            this.btnSaleRetail.TabIndex = 3;
            this.btnSaleRetail.Text = "Retail";
            this.btnSaleRetail.UseVisualStyleBackColor = false;
            // 
            // pnlPurchaseDropdown
            // 
            this.pnlPurchaseDropdown.BackColor = System.Drawing.Color.LightSeaGreen;
            this.pnlPurchaseDropdown.Controls.Add(this.btnPurchaseWholesale);
            this.pnlPurchaseDropdown.Controls.Add(this.btnPurchaseRetail);
            this.pnlPurchaseDropdown.Location = new System.Drawing.Point(122, 54);
            this.pnlPurchaseDropdown.Name = "pnlPurchaseDropdown";
            this.pnlPurchaseDropdown.Size = new System.Drawing.Size(116, 122);
            this.pnlPurchaseDropdown.TabIndex = 5;
            // 
            // btnPurchaseWholesale
            // 
            this.btnPurchaseWholesale.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnPurchaseWholesale.FlatAppearance.BorderSize = 0;
            this.btnPurchaseWholesale.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPurchaseWholesale.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPurchaseWholesale.ForeColor = System.Drawing.SystemColors.Control;
            this.btnPurchaseWholesale.Location = new System.Drawing.Point(0, 60);
            this.btnPurchaseWholesale.Name = "btnPurchaseWholesale";
            this.btnPurchaseWholesale.Size = new System.Drawing.Size(116, 54);
            this.btnPurchaseWholesale.TabIndex = 4;
            this.btnPurchaseWholesale.Text = "Wholesale";
            this.btnPurchaseWholesale.UseVisualStyleBackColor = false;
            // 
            // btnPurchaseRetail
            // 
            this.btnPurchaseRetail.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnPurchaseRetail.FlatAppearance.BorderSize = 0;
            this.btnPurchaseRetail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPurchaseRetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPurchaseRetail.ForeColor = System.Drawing.SystemColors.Control;
            this.btnPurchaseRetail.Location = new System.Drawing.Point(0, 0);
            this.btnPurchaseRetail.Name = "btnPurchaseRetail";
            this.btnPurchaseRetail.Size = new System.Drawing.Size(116, 54);
            this.btnPurchaseRetail.TabIndex = 3;
            this.btnPurchaseRetail.Text = "Retail";
            this.btnPurchaseRetail.UseVisualStyleBackColor = false;
            // 
            // picTick
            // 
            this.picTick.Image = ((System.Drawing.Image)(resources.GetObject("picTick.Image")));
            this.picTick.Location = new System.Drawing.Point(7, 17);
            this.picTick.Name = "picTick";
            this.picTick.Size = new System.Drawing.Size(21, 21);
            this.picTick.TabIndex = 6;
            this.picTick.TabStop = false;
            // 
            // CustomizedMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(602, 345);
            this.Controls.Add(this.pnlPurchaseDropdown);
            this.Controls.Add(this.pnlSaleDropdown);
            this.Controls.Add(this.pnlMenu);
            this.Name = "CustomizedMenu";
            this.Text = "Customized Menu";
            this.Load += new System.EventHandler(this.CustomizedMenu_Load);
            this.Click += new System.EventHandler(this.CustomizedMenu_Click);
            this.pnlMenu.ResumeLayout(false);
            this.pnlSaleDropdown.ResumeLayout(false);
            this.pnlPurchaseDropdown.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picTick)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMenu;
        private System.Windows.Forms.Button btnSale;
        private System.Windows.Forms.Button btnPurchase;
        private System.Windows.Forms.Panel pnlSaleDropdown;
        private System.Windows.Forms.Button btnSaleWholesale;
        private System.Windows.Forms.Button btnSaleRetail;
        private System.Windows.Forms.Panel pnlPurchaseDropdown;
        private System.Windows.Forms.Button btnPurchaseWholesale;
        private System.Windows.Forms.Button btnPurchaseRetail;
        private System.Windows.Forms.PictureBox picTick;
    }
}

