﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidTermExam
{
    public partial class CustomizedMenu : Form
    {
        public CustomizedMenu()
        {
            InitializeComponent();
        }

        // This functions takes a button object as its argument
        // When this function is called it will make the picture visible
        // and it takes the left margin of the passed button + 5 points
        // and add that margin to the left of the picture
        void imageMoover(Button btn)
        {
            picTick.Visible = true;
            picTick.Left = btn.Left + 5;
        }


        // When the form is loaded this function will make 2 panels and picture invisible
        private void CustomizedMenu_Load(object sender, EventArgs e)
        {
            pnlPurchaseDropdown.Visible = false;
            pnlSaleDropdown.Visible = false;
            picTick.Visible = false;
        }


        // when this button is clicked it makes the its dropdown panel visible and
        // it makes other dropdowns invisible, and it calls the imageMoover function
        // and passes this button as argument to get the left margin of the button and
        // and to the left margin of the picture
        private void BtnSale_Click(object sender, EventArgs e)
        {
            pnlSaleDropdown.Visible = true;
            pnlPurchaseDropdown.Visible = false;
            imageMoover(btnSale);
        }

        // Same as above function
        private void BtnPurchase_Click(object sender, EventArgs e)
        {
            pnlPurchaseDropdown.Visible = true;
            pnlSaleDropdown.Visible = false;
            imageMoover(btnPurchase);
        }

        // when we click on the form it will invisible sale and purchase 
        // panels and picture

        private void CustomizedMenu_Click(object sender, EventArgs e)
        {
            pnlSaleDropdown.Visible = false;
            pnlPurchaseDropdown.Visible = false;
            picTick.Visible = false;
        }

        // If a button is clicked it means that the picture is visible
        // this function will make visible the dropdown panel of the button
        // if picture is visible
        private void BtnSale_MouseEnter(object sender, EventArgs e)
        {
            if(picTick.Visible == true)
            {
                btnSale.PerformClick();
            }
        }


        // Same as above function
        private void BtnPurchase_MouseEnter(object sender, EventArgs e)
        {
            if (picTick.Visible == true)
            {
                btnPurchase.PerformClick();
            }
        }
    }
}
